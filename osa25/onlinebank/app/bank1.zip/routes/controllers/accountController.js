//import * as bcrypt from "https://deno.land/x/bcrypt@v0.4.1/mod.ts";
import * as accountService from "../../services/accountService.js";

const showAccounts = async ({ request, response , state, render }) => {
  const user = await state.session.get("user");
  const authenticated = await state.session.get("authenticated");
  console.log(user, authenticated);
  if (!authenticated) {
    response.status = 401;
    return;
  }

  const accounts = await accountService.findAccountsWithId(user.id);
  user.accounts = accounts;
  console.log(user);
  await state.session.set("user", user)
  render("accounts.eta", user);
};

const createAccount = async ({ request, response , state, render }) => {
  const user = await state.session.get("user");
  console.log(user);
  if (!user) {
    response.status = 401;
    return;
  }
  const body = request.body();
  const params = await body.value;

  const name = params.get("name");
  await accountService.addAccount(name, user.id)
  response.redirect("/accounts");
};

export {
  showAccounts,
  createAccount,
};
