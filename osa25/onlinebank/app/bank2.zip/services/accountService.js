import { sql } from "../database/database.js";

const findUsersWithEmail = async (email) => {
  return await sql`SELECT * FROM users WHERE email = ${ email }`;
};

const addAccount = async (name, user_id) => {
  await sql`INSERT INTO accounts (name, balance, user_id) VALUES (${ name }, 0, ${ user_id })`;
};

const findAccountsWithId = async (user_id) => {
  return await sql`SELECT * FROM accounts WHERE user_id = ${ user_id }`;
};

const findOneAccountWithIds = async (accountId, userId) => {
  return await sql`SELECT * FROM accounts WHERE id = ${accountId} AND user_id = ${userId}`;
};

export { addAccount, findUsersWithEmail, findAccountsWithId, findOneAccountWithIds };
